# J.A.R.V.I.S. — Complete Windows Setup Guide

This guide assumes Windows 10/11 and a local computer running the AI services. Install only the services you plan to use.

## 1. Install Python 3.11 (64-bit)

1. Download Python 3.11 for Windows from https://www.python.org/downloads/.
2. Run the installer. Enable the Python Launcher (`py`) if offered. Adding Python to PATH is also helpful.
3. Open PowerShell and verify:
   ```powershell
   py -3.11 --version
   ```
   It should report Python 3.11.x.

Python 3.11 is the recommended runtime because it supports the current Piper package path used by this project. The app also includes a worker fallback that can invoke Python 3.11 if the main interpreter cannot import Piper.

## 2. Install Ollama (AI chat)

1. Download and install Ollama for Windows: https://ollama.com/download/windows
2. Open PowerShell.
3. Download the default model:
   ```powershell
   ollama pull qwen3.5:4b
   ```
4. Confirm it is installed:
   ```powershell
   ollama list
   ```
5. Ollama normally runs as a background app/service. If it is not running, start it in a separate terminal:
   ```powershell
   ollama serve
   ```
6. Keep Ollama running while using J.A.R.V.I.S. The default API address is `http://127.0.0.1:11434`.

If you use a different model, set `JARVIS_MODEL` in `.env` to the exact model name shown by `ollama list`.

## 3. Install ComfyUI (optional: images and videos)

1. Follow the current Windows Desktop installation guide: https://docs.comfy.org/installation/desktop/windows
2. Launch ComfyUI and confirm its web interface is available at `http://127.0.0.1:8188`.
3. Install at least one compatible checkpoint. For the default Stable Diffusion workflow, place `v1-5-pruned-emaonly.safetensors` in ComfyUI's `models/checkpoints` directory.
4. Refresh the J.A.R.V.I.S. Image Lab and check that the checkpoint appears in the model selector.
5. Start with 512×512 and the Fast or Balanced preset. Larger checkpoints and resolutions can exceed available VRAM.

The app builds API workflows for supported single-file Stable Diffusion/FLUX checkpoints. A checkpoint alone does not guarantee compatibility with every ComfyUI version or model family. If a model requires separate text encoders, VAE files, custom nodes, or a specialized workflow, install those according to that model's documentation.

### Optional video generation

Video generation is an advanced, optional ComfyUI integration. J.A.R.V.I.S. does not include video models or custom nodes. Install a compatible ComfyUI video workflow and all of its required nodes/models. In ComfyUI, enable Developer Mode if needed, load and test the workflow, then use **Save (API Format)**. Paste the API JSON into the J.A.R.V.I.S. Video Lab and save it. The workflow is stored locally as `video_workflow_api.json`.

## 4. Download this J.A.R.V.I.S. project

1. Download the repository ZIP from GitHub, or clone it with Git.
2. Extract it to a normal writable folder, for example `C:\Projects\JARVIS`.
3. Do not put `.env`, voice models, or generated media into a public repository.

## 5. Install J.A.R.V.I.S. Python dependencies

Double-click `setup_windows.bat`. It:
- Creates a project-local `.venv` using Python 3.11.
- Updates pip.
- Installs Flask, Requests, python-dotenv, and Piper TTS.
- Copies `.env.example` to `.env` if no local configuration exists.
- Creates empty runtime folders.

If Windows blocks the batch file, open PowerShell in the project folder and run:

```powershell
py -3.11 -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
Copy-Item .env.example .env -ErrorAction SilentlyContinue
```

## 6. Start J.A.R.V.I.S.

Double-click `start_jarvis.bat`, or run:

```powershell
.\.venv\Scripts\python.exe app.py
```

Open http://127.0.0.1:5000 in Chrome or Edge. Keep the terminal window open. Press Ctrl+C in that window to stop the Flask server.

## 7. Configure and test chat

1. Confirm Ollama is running and `ollama list` shows the model named in `.env`.
2. Open J.A.R.V.I.S. and wait for the status indicator.
3. Send a short test message.
4. Try a longer response and test **Cancel**.
5. Open the model selector and switch between installed models.

## 8. Configure Piper voices

Piper local synthesis is included in `requirements.txt`. The project does not ship downloaded voice models.

1. Open J.A.R.V.I.S. Settings.
2. Set the TTS engine to **Piper**.
3. Switch the network control to **ONLINE** temporarily.
4. Choose **Browse Available Voices**.
5. Search for an English voice, preferably a small/medium model for the first test.
6. Select it and choose **Install Selected**.
7. Choose **Test Selected**.
8. Switch back to **OFFLINE** when finished if you do not need web search or further downloads.

Voice model files are saved in `piper_voices/`. They are not committed to Git and can be downloaded again on a new computer. Local synthesis does not require the old Piper HTTP server on port 5005. That server is supported as an optional fallback through `JARVIS_PIPER_URL`.

If you intentionally use the separate Piper HTTP server, install/start it separately and keep its address in `.env`. The default fallback URL is `http://127.0.0.1:5005`.

## 9. Microphone, wake word, and camera

- Use a recent Chrome or Edge browser.
- Allow microphone permission when prompted.
- Speech recognition support varies by browser and may use an online browser service even when J.A.R.V.I.S. is in OFFLINE mode. The offline switch controls J.A.R.V.I.S. web search/image search and voice catalog downloads; it cannot force browser speech recognition to be offline.
- Camera/live vision requires a webcam and browser camera permission. Use `http://127.0.0.1` rather than a remote insecure IP address so browser device permissions work as expected.

## 10. Data and backups

Runtime data locations:

| Folder/file | What it stores | Included in Git? |
|---|---|---|
| `piper_voices/` | Downloaded `.onnx` voice models and JSON configs | No |
| `generated_images/` | Image output from ComfyUI | No |
| `generated_videos/` | Video output from ComfyUI | No |
| `image_benchmarks.json` | Locally measured image generation times | No; recreated |
| `video_workflow_api.json` | Your saved ComfyUI API workflow | No; configure per machine |
| `jarvis_workspace/` | Files you create in the built-in IDE | No |
| Browser local storage | Chat history and UI settings | No |

To move to another computer, download/clone the source, repeat setup, install Ollama and ComfyUI, pull the model, and download the Piper voice(s) again. Re-create your optional video workflow. If you want to keep your own workspace files or custom workflow, back them up separately before moving.

## 11. Local configuration options

Edit `.env` and restart J.A.R.V.I.S.:

```ini
JARVIS_HOST=127.0.0.1
JARVIS_PORT=5000
JARVIS_OLLAMA_URL=http://127.0.0.1:11434
JARVIS_MODEL=qwen3.5:4b
JARVIS_COMFY_URL=http://127.0.0.1:8188
JARVIS_PIPER_URL=http://127.0.0.1:5005
```

Keep `JARVIS_HOST=127.0.0.1` for same-computer access. Binding to all network interfaces is not recommended without additional access controls.
