@echo off
setlocal
cd /d "%~dp0"
title J.A.R.V.I.S. Local Server
if not exist ".venv\Scripts\python.exe" (
  echo Project environment is missing. Run setup_windows.bat first.
  pause
  exit /b 1
)
echo Starting J.A.R.V.I.S. at http://127.0.0.1:5000
echo Keep this window open while using J.A.R.V.I.S.
echo Press Ctrl+C to stop the server.
".venv\Scripts\python.exe" app.py
pause
