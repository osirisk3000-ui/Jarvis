Optional static assets for the J.A.R.V.I.S. interface belong in this folder.
The original jarvis_core.webp image referenced by the earlier build was not included in the source handoff. The new interface has a CSS-rendered reactor fallback and works without that image. If you have the original image, place it here as jarvis_core.webp.
