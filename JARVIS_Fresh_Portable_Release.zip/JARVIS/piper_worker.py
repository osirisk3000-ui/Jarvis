"""Small subprocess worker for Piper TTS on a compatible Python installation.

The Flask app sends UTF-8 text on stdin. This worker writes a WAV file to stdout.
"""
from __future__ import annotations

import sys
import wave
from pathlib import Path
from io import BytesIO

from piper.voice import PiperVoice


def main() -> int:
    if len(sys.argv) < 2:
        print("Usage: piper_worker.py <voice.onnx> [speed]", file=sys.stderr)
        return 2

    model_path = Path(sys.argv[1]).resolve()
    if not model_path.is_file():
        print(f"Voice model not found: {model_path}", file=sys.stderr)
        return 2

    try:
        speed = float(sys.argv[2]) if len(sys.argv) > 2 else 1.0
    except ValueError:
        speed = 1.0
    speed = max(0.6, min(1.6, speed))
    text = sys.stdin.buffer.read().decode("utf-8", errors="replace").strip()
    if not text:
        print("No text received", file=sys.stderr)
        return 2

    voice = PiperVoice.load(str(model_path), config_path=str(model_path) + ".json")
    output = BytesIO()
    with wave.open(output, "wb") as wav:
        try:
            from piper.config import SynthesisConfig
            voice.synthesize_wav(text, wav, syn_config=SynthesisConfig(length_scale=1.0 / speed))
        except (ImportError, TypeError):
            # Older Piper versions may not expose SynthesisConfig.
            voice.synthesize_wav(text, wav)
    sys.stdout.buffer.write(output.getvalue())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
