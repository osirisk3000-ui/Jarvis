# Troubleshooting

## `py -3.11` is not recognized

Install Python 3.11 (64-bit) from https://www.python.org/downloads/ and enable the Python Launcher. Close and reopen PowerShell after installation.

## `setup_windows.bat` fails while installing packages

- Confirm `py -3.11 --version` works.
- In the project folder, remove the `.venv` folder only if its environment is broken, then rerun `setup_windows.bat`.
- Check that the computer has internet access during dependency installation.
- If a package build fails, copy the complete error from the terminal; do not randomly install unrelated packages.

## J.A.R.V.I.S. page does not open

- Confirm the `start_jarvis.bat` terminal is still running.
- Open `http://127.0.0.1:5000`.
- Check that `JARVIS_PORT` in `.env` is still `5000` and that another app is not using that port.

## Ollama is offline or no model is available

- Start the Ollama app or run `ollama serve` in a separate terminal.
- Run `ollama list`.
- If the default model is missing, run `ollama pull qwen3.5:4b`.
- If you installed a different model, update `JARVIS_MODEL` in `.env` to its exact name and restart J.A.R.V.I.S.
- Check `JARVIS_OLLAMA_URL` if Ollama is running on a different local address.

## ComfyUI is offline or no checkpoint appears

- Start ComfyUI and open `http://127.0.0.1:8188` directly.
- Confirm the checkpoint is in ComfyUI's `models/checkpoints` folder.
- Refresh the Image Lab connection status.
- If ComfyUI uses another port, update `JARVIS_COMFY_URL` in `.env` and restart J.A.R.V.I.S.
- Check the ComfyUI terminal for missing nodes, model files, or VRAM errors.

## Image generation runs out of memory or is very slow

- Start with a 512×512 image and the Fast preset.
- Close other GPU-heavy applications.
- Use a smaller checkpoint compatible with your GPU.
- FLUX, XL checkpoints, and video workflows can require considerably more VRAM than SD 1.5.

## Piper voice list is empty

- Set the J.A.R.V.I.S. network mode to ONLINE while browsing/downloading voices.
- Check that the computer can reach the Piper voice catalog on Hugging Face.
- Confirm `piper-tts` installed in `.venv` with:
  ```powershell
  .\.venv\Scripts\python.exe -m pip show piper-tts
  ```
- Ensure the `piper_voices` folder is writable.

## Piper synthesis fails

- Confirm the selected voice has both its `.onnx` and `.onnx.json` files in `piper_voices/`.
- Install the package again with:
  ```powershell
  .\.venv\Scripts\python.exe -m pip install --upgrade piper-tts
  ```
- If using an external Piper server, check its address in `JARVIS_PIPER_URL` and verify it is listening.
- Check the Flask terminal for the full error message.

## Microphone or wake word does not work

- Use current Chrome or Edge.
- Allow microphone access for `http://127.0.0.1:5000`.
- Check that Windows has not muted or blocked the microphone.
- SpeechRecognition availability and online/offline behavior depend on the browser; it is not a guaranteed offline speech-to-text engine.

## Camera/live vision does not work

- Allow camera access in the browser and Windows privacy settings.
- Close other apps that may be using the webcam.
- Use the local `127.0.0.1` address.

## Video Lab reports workflow errors

- Video generation requires a saved ComfyUI API-format workflow.
- Confirm every custom node and model referenced by that workflow is installed.
- Test the workflow directly in ComfyUI first.
- Check the ComfyUI terminal for missing node or memory errors.

## Old conversations appear unexpectedly

This release uses a new storage namespace (`jarvis-retroglass-v4`) and removes the previous v3 chat record and old attachment database once on first load at the same browser origin. If an older deployment is still open in another tab, close it and hard-refresh this one with Ctrl+Shift+R.

## Still stuck?

Collect the first relevant error from:
1. The J.A.R.V.I.S. terminal window.
2. The browser Developer Tools Console (F12 → Console).
3. The Ollama or ComfyUI terminal, depending on the feature.

Share the error text, but remove personal paths, usernames, private IP addresses, tokens, and other secrets first.
