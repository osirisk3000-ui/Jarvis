# Changelog

## Fresh portable rebuild

- Consolidated the supplied Flask backend and Retro Glass web interface into one clean project layout.
- Preserved Ollama streaming chat, model selection, response timing/statistics, and cancellation.
- Preserved local Piper voice catalog/download/synthesis and added the supplied Python worker as a fallback.
- Preserved ComfyUI image generation, local gallery, benchmark-based estimates, and optional video workflow routes.
- Preserved web search/image search, file uploads, and the restricted browser IDE workspace.
- Moved service URLs, default model, host, and port into `.env` configuration.
- Changed the default Flask bind address from all interfaces to localhost for safer first-run behavior.
- Added Windows setup/start scripts, dependency list, full setup guide, and troubleshooting notes.
- Changed browser storage to a fresh namespace and added a one-time cleanup of the previous v3 chat record and attachment database.
- Removed references to the original user's Downloads folder and username from setup/error instructions.
- Excluded generated media, downloaded voice models, old benchmark data, old video workflow data, and old experimental workspace files from the clean release.
- Added a CSS-rendered reactor fallback because the referenced `static/jarvis_core.webp` image was not supplied as an actual file in the source handoff.

## Excluded legacy experiments

- `test.py` contained malformed test text and was not included.
- `jarvis_code.html` was a standalone clicker demo, not part of the main application, and was not included.
- Old generated image JSON, image benchmark samples, voice model files, chat history, and generated media were not copied into the release.
