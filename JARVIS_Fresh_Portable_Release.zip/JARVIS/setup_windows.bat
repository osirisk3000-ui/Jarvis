@echo off
setlocal
cd /d "%~dp0"
title J.A.R.V.I.S. Setup

echo ================================================
echo        J.A.R.V.I.S. - FIRST TIME SETUP
echo ================================================

py -3.11 --version >nul 2>&1
if errorlevel 1 (
  echo Python 3.11 was not found.
  echo Install Python 3.11 x64 from https://www.python.org/downloads/ first.
  echo During setup, enable the Python Launcher option.
  pause
  exit /b 1
)

if not exist ".venv\Scripts\python.exe" (
  echo Creating the project virtual environment...
  py -3.11 -m venv .venv
  if errorlevel 1 goto failed
)

echo Updating pip...
".venv\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 goto failed

echo Installing J.A.R.V.I.S. dependencies...
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto failed

if not exist ".env" copy ".env.example" ".env" >nul
for %%D in (static piper_voices generated_images generated_videos jarvis_workspace) do if not exist "%%D" mkdir "%%D"

echo.
echo Setup complete.
echo Next: install Ollama and ComfyUI, then run start_jarvis.bat.
echo See README.md and SETUP_GUIDE.md for full instructions.
pause
exit /b 0

:failed
echo.
echo Setup failed. Check the error above and see TROUBLESHOOTING.md.
pause
exit /b 1
